<?php

$mvc = new MvcController();

include "modules/navegacion.php";
$mvc->enlacesPaginasController();

?>

<script src="ajax/jquery-3.0.0.min.js"></script>

<script src="ajax/ajax.js?v=8.0"></script>